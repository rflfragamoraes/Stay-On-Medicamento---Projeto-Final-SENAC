export interface UsuarioCadastrarDto{
    nome: string;
    email: string;
    senha: string;
    amigo: string;
    celamigo: string;
}