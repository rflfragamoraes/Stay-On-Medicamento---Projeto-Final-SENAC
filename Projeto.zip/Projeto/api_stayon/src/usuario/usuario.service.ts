import { Injectable, Inject } from '@nestjs/common';
import { ResultadoDto } from 'src/dto/resultado.dto';
import { Repository } from 'typeorm';
import { UsuarioCadastrarDto } from './dto/usuario.cadastrar.dto';
import { Usuario } from './usuario.entity';
import * as bcrypt from 'bcrypt';




@Injectable()
export class UsuarioService {
  constructor(
    @Inject('USUARIO_REPOSITORY')
    private usuarioRepository: Repository<Usuario>,
  ) {}

  async listar(): Promise<Usuario[]> {
    return this.usuarioRepository.find();
  }

  async cadastrar (data: UsuarioCadastrarDto): Promise<ResultadoDto>{
    let usuario = new Usuario()
    usuario.nome = data.nome
    usuario.email = data.email
    usuario.senha = bcrypt.hashSync(data.senha, 8)
    usuario.amigo = data.amigo
    usuario.celamigo = data.celamigo
    return this.usuarioRepository.save(usuario)
    .then((result) => {
      return <ResultadoDto>{
        status: true,
        mensagem: 'Usuario Cadastrado com sucesso'
      }
    })
    .catch((error) =>{
      return <ResultadoDto>{
        status: false,
        mensagem: 'Houve um erro ao cadasdtrar o usuario'
      }
    })  
  }  

  async findOne(email: string): Promise<Usuario | undefined> {
    return this.usuarioRepository.findOneBy({email: email});
  }
}
