import React, { useState, useMemo, useEffect } from 'react';
import {View, Text, TouchableOpacity, SafeAreaView} from 'react-native';
import {Picker} from '@react-native-picker/picker';
import {DateTimePickerModal} from "react-native-modal-datetime-picker";
import { Button} from '@rneui/themed';
import remedio from '../data/remedio.json';
import styles from '../style/MainStyle';




export default function CriarAlarme({navigation}) {


  //const usadas para criacao do CriarAlarme
  const [remedioSelecionado, setRemedioSelecionado] = useState ([null]);
  const [repetirSelecionado, setRepetirSelecionado] = useState ([null]);
  const [periodoSelecionado, setPeriodoSelecionado] = useState ([null]);
  const [isDatePickerVisible, setDatePickerVisibility] = useState(false);
  const [isTimePickerVisible, setTimePickerVisibility] = useState(false);
  const [data, setData] = useState('');
  const [hora, setHora] = useState('');
  const [remedioSelecionadoError, setRemedioSelecionadoError] = useState(null);
  const [repetirSelecionadoError, setRepetirSelecionadoError] = useState(null);
  const [periodoSelecionadoError, setPeriodoSelecionadoError] = useState(null);
  const [dataError, setDataError] = useState(null);
  const [horaError, setHoraError] = useState(null); 
  const [telaAlarme, setTelaAlarme] = useState ([]);



  //Funcoes para validar e cadastrar campos da tela CriarAlarme
  const validar = () => {
    let error = false;
    setRemedioSelecionadoError(null);
    setRepetirSelecionadoError(null);
    setPeriodoSelecionadoError(null);
    setDataError(null);
    setHoraError(null);
    if(remedioSelecionadoError == null){
      setRemedioSelecionadoError('*Selecione um medicamento');
      error = true;
    }if(repetirSelecionadoError == null){
      setRepetirSelecionadoError('*Selecione o periodo de repeticao');
      error = true;
    }if(periodoSelecionadoError == null){
      setPeriodoSelecionadoError('*Selecione um periodo');
      error = true;
    }if(dataError == null){
      setDataError('*Selecione uma data');
      error = true;
    }if(horaError == null){
      setHoraError('*Selecione uma hora');
      error = true;
    }
    return !error;
   };

  const registrarAlarme = ()=> {
    if(validar()){
      
      navigation.reset({
      index: 0,
      routes: [{name: "Principal"}]     
      })
    }    
  };  


  //funcao para abrir modal e pegar a data
  const onChangeDate = date =>{
    setData(date);
  };
  const showDatePicker = () => {
    setDatePickerVisibility(true);
  };
  const hideDatePicker = () => {
    setDatePickerVisibility(false);
  };
  const handleConfirm = (date) => {
    setDataError(null);
    const dia = String(date. getDate());
    const mes = String(date. getMonth() + 1). padStart(2, '0');
    const ano = date. getFullYear();
    onChangeDate(dia + '/' + mes + '/'+ ano);
    hideDatePicker();
  };


  //funcao para abrir modal e pegar a hora
  const onChangeTime = time =>{
    setHora(time);
  };
  const showTimePicker = () => {
    setTimePickerVisibility(true);
  };
  const hideTimePicker = () => {
    setTimePickerVisibility(false);
  };
  const handleTimeConfirm = (time) => {
    setHoraError(null);
    const hora = time.getHours();
    const minutos = time.getMinutes();
    onChangeTime(hora +':'+ minutos); 
    hideTimePicker();
  };   

  return (
    <View style={styles.container}>     
      <TouchableOpacity 
          style={styles.buttonRegistrar}
          onPress={() => registrarAlarme()}       
      >
      <Text style={styles.textButtonRegistrar}>Registar</Text>
      </TouchableOpacity>  
        <View style={styles.boxContext}>
          <Text style={styles.textRegistrar}>
            Nome do medicamento:
          </Text>
          < Picker style={styles.pickerRegistrar}
            selectedValue = {remedioSelecionado} 
            onValueChange = { (itemValue)  => {
              setRemedioSelecionado (itemValue)
              setRemedioSelecionadoError(null)              
            }}
            >         
              <Picker.Item label='' value=''/>  
              <Picker.Item label='Amoxilina' value='Amoxilina'/>
              <Picker.Item label='Aspirina' value='Aspirina'/>
              <Picker.Item label='Dipirona' value='Dipirona'/>
              <Picker.Item label='Dorflex' value='Dorflex'/>
              <Picker.Item label='Paracetamol' value='Paracetamol'/>   
          </Picker>  
          <Text style={styles.errorMessage}>{remedioSelecionadoError}</Text> 
          <View>
          <Text style={styles.textRegistrarAdaptado}>
            Data do início do tratamento:
          </Text>  
          <Text style={styles.textImputData}>{data.toString()}</Text>      
            <Button
            title="" 
            color="#646464"
            containerStyle={{
              width: 80,
              marginHorizontal: 240,
              marginVertical: -45,              
            }}      
            icon={{
              name: 'calendar',
              type: 'font-awesome',
              size: 25,
              color: `#ffc640`,
            }}      
            onPress={showDatePicker} 
            />     
            <DateTimePickerModal
              isVisible={isDatePickerVisible}
              mode="date"
              value={data}
              onConfirm={handleConfirm}
              onCancel={hideDatePicker}           
            />
            <Text style={styles.errorMessagePicker}>{dataError}</Text>
          </View> 
          <View>
          <Text style={styles.textDataRegistrar}>
            Hora do início do tratamento:
          </Text>  
          <Text style={styles.textImputData}>{hora.toString()}</Text>      
            <Button 
            title="" 
            color="#646464"
            containerStyle={{
              width: 80,
              marginHorizontal: 240,
              marginVertical: -45,              
            }}
            icon={{
              name: 'hourglass',
              type: 'font-awesome',
              size: 25,
              color: `#ffc640`,
            }}
            onPress={showTimePicker} 
            />
            <DateTimePickerModal
              isVisible={isTimePickerVisible}
              mode="time"
              onConfirm={handleTimeConfirm}
              onCancel={hideTimePicker}
            />
          </View>            
          <Text style={styles.errorMessagePicker}>{horaError}</Text>
          <Text style={styles.textDataRegistrar}>
           Repetir:
          </Text>          
          < Picker style={styles.pickerRegistrar}
            selectedValue = {repetirSelecionado} 
            onValueChange = { (itemValue)  => {
              setRepetirSelecionado (itemValue)
              setPeriodoSelecionadoError(null)
              
            }}
            >         
              <Picker.Item label='' value=''/>  
              <Picker.Item label='a cada 1 minuto' value='1'/>
              <Picker.Item label='a cada 4 horas' value='4'/>
              <Picker.Item label='a cada 6 horas' value='6'/>
              <Picker.Item label='a cada 8 horas' value='8'/>
              <Picker.Item label='a cada 12 horas' value='12'/>
              <Picker.Item label='a cada 24 horas' value='24'/>    
          </Picker>  
          <Text style={styles.errorMessage}>{periodoSelecionadoError}</Text>
          <Text style={styles.textRegistrarAdaptado}>
           Período do tratamento:
          </Text>         
          < Picker style={styles.pickerRegistrar}
            selectedValue = {periodoSelecionado} 
            onValueChange = { (itemValue)  => {
              setPeriodoSelecionado (itemValue)
              setRepetirSelecionadoError(null)
            }}
            >         
              <Picker.Item label='' value=''/>  
              <Picker.Item label='Diariamente' value='Diariamente'/>
              <Picker.Item label='1 dias' value='1'/>
              <Picker.Item label='2 dias' value='2'/>
              <Picker.Item label='4 dias' value='4'/>
              <Picker.Item label='5 dias' value='5'/>
              <Picker.Item label='7 dias' value='7'/>
              <Picker.Item label='15 dias' value='15'/>
              <Picker.Item label='30 dias' value='30'/>                
          </Picker> 
          <Text style={styles.errorMessageLast}>{repetirSelecionadoError}</Text>          
        </View>
    </View> 
  );
}

