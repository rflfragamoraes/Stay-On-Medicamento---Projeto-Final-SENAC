import React, { useState } from 'react';
import { View, Text, TouchableOpacity, FlatList, SafeAreaView} from 'react-native';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import {Card} from 'react-native-shadow-cards';
import { PieChart } from 'react-native-svg-charts';
import { Text as TextSvg} from 'react-native-svg';
import styles from '../style/MainStyle';


// Funcao de navegacao para tela CriarAlarme
const Alarme = ({navigation}) => {  
  
  const cadastrarAlarme = ()=> { 
    navigation.navigate("CriarAlarme");   
  } 
   return (
    <View style={styles.container} >
      <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center'}}>
        <TouchableOpacity 
            style={styles.buttonModal}
            onPress={() => cadastrarAlarme()}
          >
            <Text style={styles.textButtonModal}>Cadastrar Alarme</Text>
        </TouchableOpacity>  
        <View>        
          <Card style={styles.card}>
          <Text style={styles.textAlarme}>Dorflex</Text>
            <Text style={styles.textAlarmeAtivoDesativo}>Ativado/Desativado</Text>
            <Text style={styles.textAlarmeHora}>hora</Text>
            <TouchableOpacity style={styles.buttonParar}>
              <Text style={styles.textParar}>Parar</Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.buttonAtivar}>
              <Text style={styles.textAtivar}>Ativar</Text>
            </TouchableOpacity>
            <TouchableOpacity style={styles.buttonFechar}>
              <Text style={styles.textEncerar}>X</Text>
            </TouchableOpacity>            
          </Card>  
          <Card style={styles.card}>
            
          </Card> 
          <Card style={styles.card}>
            
          </Card>
          <Card style={styles.card}>
            
          </Card>        
        </View>                
      </View>  
    </View>    
  )
}


// Funcao de navegacao para tela CriarMedico
const Consulta = ({navigation}) => {
  const cadastrarConsulta = ()=> {
    navigation.navigate("CriarMedico");
  }
  return (
    <View style={styles.container} >
      <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
        <TouchableOpacity 
            style={styles.buttonModal}
            onPress={() => cadastrarConsulta()}
          >
            <Text style={styles.textButtonModal}>Cadastrar Consulta Medica</Text>
        </TouchableOpacity> 
          <View>
            <Card style={styles.card}>

            </Card>
            <Card style={styles.card}>

            </Card>
            <Card style={styles.card}>

            </Card> 
            <Card style={styles.card}>

            </Card>
          </View>   
      </View>
    </View>
  );
}

// Funcao de navegacao para tela Evolucao
const Evolucao = ({navigation}) => {  
  
  const registrarConsumo = () => {

  }
  const verTabela = () => {
    navigation.navigate("Tabela");
  }

  // Funcao do grafico para tela Evolucao
  const certo = 10;
  const atrasado = 5;
  const esqueceu = 2;
  const data = [certo, atrasado, esqueceu,];
 
  const pieData = data.map((value, index) => ({
    value,
    key: `${index}-${value}`,
    svg: {
    fill: "#32a726"
    }               
  }));
     const Label = ({slices}) => {
      return slices.map((slice, index) => {
        const {pieCentroid, data} = slice;
        return(
        <TextSvg
          key= {`label-${index}`}
          x={pieCentroid[0]}
          y={pieCentroid[1]}
          fill= "#000000"
          textAnchor= {'middle'}
          alignmentBaseline= {'middle'}
          fontSize={24}          
        >
          {data.value}          
        </TextSvg>
        );
      });
     }
     
  return(

      <View style={{ flex: 1, justifyContent: 'center'}}>
        <View>
          <PieChart
          style={{ height: 300, marginBottom: 100 }} 
          data={pieData} 
          >
          <Label/>
          </PieChart>
        </View>
       <TouchableOpacity 
          style={styles.buttonRegistrarConsumo}
          onPress={() => registrarConsumo()}        
        >
            <Text style={styles.textButtonLogin}>Registrar Consumo</Text>
        </TouchableOpacity>
        <TouchableOpacity 
          style={styles.buttonVerTabela}
          onPress={() => verTabela()}  
        >
          <Text style={styles.textButtonLogin}>Ver Tabela</Text>
        </TouchableOpacity>
      </View>        
  )  
}

const Tab = createBottomTabNavigator();

export default function Principal({navigation}) { 
  
  return (
    <Tab.Navigator
      initialRouteName="Alarme"
      screenOptions={{
        tabBarActiveTintColor: '#ffc640',
      }}
    >
      <Tab.Screen
        name="Feed"
        component={Alarme}
        options={{
          title: "",
          headerShown: false,
          tabBarLabel: 'Alarmes',
          tabBarIcon: ({ color, size }) => (
            <MaterialCommunityIcons name="alarm" color={color} size={size} />
          ),
        }}
      />      
      <Tab.Screen
        name="Consulta"
        component={Consulta}
        options={{
          title: "",
          headerShown: false,
          tabBarLabel: 'Consultas',
          tabBarIcon: ({ color, size }) => (
            <MaterialCommunityIcons name="pen" color={color} size={size} />
          ),
        }}
      />
      <Tab.Screen
        name="Evolucao"
        component={Evolucao}
        options={{
          title: "",
          headerShown: false,
          tabBarLabel: 'Evolução',
          tabBarIcon: ({ color, size }) => (
            <MaterialCommunityIcons name="signal" color={color} size={size} />
          ),
        }}
      />      
    </Tab.Navigator>
  );
}




