import React, { useState } from 'react';
import {View, Text, Image, TextInput, TouchableOpacity, Pressable, Keyboard, ScrollView, Alert} from 'react-native';
import { Button, Paragraph, Dialog, Portal, Provider } from 'react-native-paper';
import styles from '../style/MainStyle';
import { TextInputMask } from 'react-native-masked-text';
import usuarioService from '../services/UsuarioService';



export default function Cadastro({navigation}) {

  //const usadas para criacao do Cadastro
  const [nome, setNome] = useState(null);
  const [email, setEmail] = useState(null);
  const [senha, setSenha] = useState(null);
  const [amigo, setAmigo] = useState(null);
  const [celAmigo, setcelAmigo] = useState(null);
  const [nomeError, setNomeError] = useState(null);
  const [emailError, setEmailError] = useState(null);
  const [senhaError, setSenhaError] = useState(null);
  const [amigolError, setAmigoError] = useState(null);
  const [celAmigoError, setCelAmigoError] = useState(null);
  const [isLoading, setLoading] = useState(false);
  const [titulo, setTitulo] = useState(null);
  const [mensagem, setMensagem] = useState(null);
  const [visible, setVisible] = useState(false);
  const showDialog = () => setVisible(true);
  const hideDialog = () => {
    setVisible(false);
    navigation.reset({
      index: 0,
      routes: [{name: "Login"}]     
      })

  }


  //Funcoes para validar campos da tela Cadastro
 
  const validar = () => {
    let error = false;
    setNomeError(null);
    setEmailError(null);
    setSenhaError(null);
    setAmigoError(null);
    setCelAmigoError(null);
    const re = /^(([^<>()[\]\.,;:\s@\"]+(\.[^<>()[\]\.,;:\s@\"]+)*)|(\".+\"))@(([^<>()[\]\.,;:\s@\"]+\.)+[^<>()[\]\.,;:\s@\"]{2,})$/i;
    if(nome == null){
      setNomeError('*Preencha seu nome');
      error = true;
    }if(!re.test(String(email).toLowerCase()) ||email == null){
      setEmailError('*Preencha seu e-mail corretamente');
      error = true;
    }if(senha == null){
      setSenhaError('*Preencha sua senha corretamente');
      error = true;
    }if(amigo == null){
      setAmigoError('*Preencha o nome de um amigo');
      error = true;
    }if(celAmigo == null){
      setCelAmigoError('*Preencha o telefone de um amigo');
      error = true;
    }
    return !error;
   };

  const salvar = ()=> {
    if(validar()){

      setLoading(true)
      let data = {
        nome: nome,
        email: email,
        senha: senha,
        amigo: amigo,
        celamigo: celAmigo
      }

      usuarioService.cadastrar(data)
        .then((response) => {
          setLoading(false);
          const titulo = (response.data.status) ? 'Sucesso' : 'Erro';
          setTitulo(titulo);
          setMensagem(response.data.mensagem);          
          showDialog();     
        })
        .catch((error) => {
          setLoading(false);
          setTitulo('Erro');
          setMensagem('Houve um erro inesperado');
        })      
    }    
  };  

  return (
    <ScrollView>
    <Pressable onPress={Keyboard.dismiss} style={styles.container}>  
      <View style={styles.boxLogo}>
        <Image source={require('../img/logo.jpg')} style={styles.imagelogoCadastro}/> 
        <Text style={styles.textLogo}>Stay On</Text>
      </View>      
      <View style={styles.boxContext}>
      <TextInput 
          style={styles.imputContext}
          placeholder = "Nome"
          onChangeText = {value => {           
            setNome(value)
            setNomeError(null)
          }} 
        />
        <Text style={styles.errorMessage}>{nomeError}</Text>
                
        <TextInput 
          style={styles.imputContext}
          placeholder = "E-mail"
          keyboardType='email-address'
          onChangeText = {value => {           
            setEmail(value)
            setEmailError(null)
          }} 
        />
        <Text style={styles.errorMessage}>{emailError}</Text>        
        <TextInput 
          style={styles.imputContext}
          placeholder = "Senha"
          onChangeText = {value => {
            setSenha(value)
            setSenhaError(null)
          }}
        />
        <Text style={styles.errorMessage}>{senhaError}</Text>       
        <TextInput 
          style={styles.imputContext}
          placeholder = "Nome de um amigo"
          onChangeText = {value => {
            setAmigo(value)
            setAmigoError(null)
          }}
          
        /> 
        <Text style={styles.errorMessage}>{amigolError}</Text>        
        <TextInputMask style={styles.imputContext}
          type={'cel-phone'}
          options={{
          maskType: 'BRL',
          withDDD: true,
          dddMask: '(99) '
          }}
          placeholder = "Telefone de um amigo"
          onChangeText = {value => {
            setcelAmigo(value)
            setCelAmigoError(null)
          }}    
        /> 
        <Text style={styles.errorMessage}>{celAmigoError}</Text>
        <TouchableOpacity 
          style={styles.buttonCadastro}
          onPress={() => salvar()}        
        >
            <Text style={styles.textButtonCadastro}>Cadastrar</Text>
        </TouchableOpacity>
      </View>         
    </Pressable> 
      <Provider>
        <Portal style={styles.container}>
          <Dialog visible={visible} onDismiss={hideDialog}>
            <Dialog.Title style={styles.dialogTitulo} >{titulo}</Dialog.Title>
            <Dialog.Content>
              <Paragraph style={styles.dialogMesagem}>{mensagem}</Paragraph>
            </Dialog.Content>
            <Dialog.Actions>
              <Button style={styles.buttonMesagem} onPress={hideDialog}>FECHAR</Button>
            </Dialog.Actions>
          </Dialog>
        </Portal>
      </Provider>
    </ScrollView>
  );
}