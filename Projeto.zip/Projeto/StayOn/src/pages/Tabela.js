import React from 'react';
import { View, Image, Text, SafeAreaView} from 'react-native';
import {Card} from 'react-native-shadow-cards';
import styles from '../style/MainStyle';



export default function Tabela() {  
  return (    
    <View style={styles.container}>      
      <View style={styles.boxLogo}>
        <Image source={require('../img/logo.jpg')} style={styles.imageLogoTabela}/> 
      </View>
      <View style={styles.boxContext}> 
      <SafeAreaView>
      <Card style={styles.cardTabela}>

      </Card>
      <Card style={styles.cardTabela}>

      </Card>
      <Card style={styles.cardTabela}>

      </Card>
      <Card style={styles.cardTabela}>

      </Card>
      </SafeAreaView>

    
      
      </View>     
    </View>
  );
}