import React, { useState} from 'react';
import {View, Text, TouchableOpacity} from 'react-native';
import {Picker} from '@react-native-picker/picker';
import {Button} from '@rneui/themed';
import DateTimePickerModal from "react-native-modal-datetime-picker";
import medico from '../data/especialista.json';
import styles from '../style/MainStyle';



export default function CriarMedico({navigation}) {

  //const usadas para criacao do CriarMedico
  const [medicoSelecionado, setMedicoSelecionado] = useState ([null]);
  const [diaSelecionado, setDiaSelecionado] = useState ([null]);
  const [isDatePickerVisible, setDatePickerVisibility] = useState(false);
  const [isTimePickerVisible, setTimePickerVisibility] = useState(false);
  const [dataConsulta, setDataConsulta] = useState('');
  const [horaConsulta, setHoraConsulta] = useState('');
  const [medicoSelecionadoError, setMedicoSelecionadoError] = useState(null);
  const [diaSelecionadoError, setDiaSelecionadoError] = useState(null);
  const [dataConsultaError, setDataConsultaError] = useState(null);
  const [horaConsultaError, setHoraConsultaError] = useState(null);  
 



  //Funcoes para validar e cadastrar campos da tela CriarAlarme
  const validar = () => {
    let error = false;
    setMedicoSelecionadoError(null);
    setDiaSelecionadoError(null);
    setDataConsultaError(null);
    setHoraConsultaError(null);
    if(medicoSelecionadoError == null){
      setMedicoSelecionadoError('*Selecione um especialista');
      error = true;
    }if(diaSelecionadoError == null){
      setDiaSelecionadoError('*Selecione o tipo de aviso');
      error = true;
    }if(dataConsultaError == null){
      setDataConsultaError('*Selecione uma data');
      error = true;
    }if(horaConsultaError == null){
      setHoraConsultaError('*Selecione uma hora');
      error = true;
    }
    return !error;
   };

  const registrarMedico = ()=> {
    if(validar()){
      navigation.reset({
      index: 0,
      routes: [{name: "Principal"}]     
      })
    }    
  };    

  
  //funcao para abrir modal e pegar a dataConsulta
  const onChangeDateConsulta = date =>{
    setDataConsulta(date);
  };
  const showDatePicker = () => {
    setDatePickerVisibility(true);
  };
  const hideDatePicker = () => {
    setDatePickerVisibility(false);
  };
  const handleConfirm = (date) => {
    setDataConsultaError(null);
    const dia = String(date. getDate());
    const mes = String(date. getMonth() + 1). padStart(2, '0');
    const ano = date. getFullYear();
    onChangeDateConsulta(dia + '/' + mes + '/'+ ano);
    hideDatePicker();
  };


  //funcao para abrir modal e pegar a horaConsulta
  const onChangeTimeConsulta = time =>{
    setHoraConsulta(time);
  };  
  const showTimePicker = () => {
    setTimePickerVisibility(true);
  };
  const hideTimePicker = () => {
    setTimePickerVisibility(false);
  };
  const handleTimeConfirm = (time) => {
    setHoraConsultaError(null);
    const hora = time.getHours();
    const minutos = time.getMinutes();
    onChangeTimeConsulta(hora +':'+ minutos);  
    hideTimePicker();
  };    

  return (    
    <View style={styles.container}>     
        <TouchableOpacity 
          style={styles.buttonRegistrar}
          onPress={() => registrarMedico()}        
        >
        <Text style={styles.textButtonRegistrar}>Registar</Text>
        </TouchableOpacity>  
        <View style={styles.boxContext}>              
          <Text style={styles.textRegistrar}>
            Especialista em:
          </Text> 
          < Picker style={styles.pickerRegistrar}
            selectedValue = {medicoSelecionado} 
            onValueChange = { (itemValue)  => {
              setMedicoSelecionado (itemValue)
              setMedicoSelecionadoError(null)              
            }}
            >         
              <Picker.Item label='' value=''/>  
              <Picker.Item label='Clinico Geral' value='Clinico Geral'/>
              <Picker.Item label='Fisioterapeuta' value='Fisioterapeuta'/>
              <Picker.Item label='Neurologista' value='Neurologista'/>
              <Picker.Item label='Ostopedista' value='Ostopedista'/>
              <Picker.Item label='Pediatra' value='Pediatra'/>   
          </Picker> 
          <Text style={styles.errorMessage}>{medicoSelecionadoError}</Text>           
          <View>
          <Text style={styles.textRegistrarAdaptado}>
            Data da consulta:
          </Text> 
            <Text style={styles.textImputData}>{dataConsulta.toString()}</Text>      
              <Button 
              title="" 
              color="#646464"
              containerStyle={{
                width: 80,
                marginHorizontal: 240,
                marginVertical: -45,              
              }}
              icon={{
                name: 'calendar',
                type: 'font-awesome',
                size: 25,
                color: `#ffc640`,
              }}
              onPress={showDatePicker} 
              />
              <DateTimePickerModal
                isVisible={isDatePickerVisible}
                mode="date"
                onConfirm={handleConfirm}
                onCancel={hideDatePicker}
              />
              <Text style={styles.errorMessagePicker}>{dataConsultaError}</Text> 
          </View>   
          <View>
            <Text style={styles.textDataRegistrar}>
              Hora da consulta:
            </Text>  
            <Text style={styles.textImputData}>{horaConsulta.toString()}</Text>      
              <Button 
              title="" 
              color="#646464"
              containerStyle={{
                width: 80,
                marginHorizontal: 240,
                marginVertical: -45,              
              }}
              icon={{
                name: 'hourglass',
                type: 'font-awesome',
                size: 25,
                color: `#ffc640`,
              }}
              onPress={showTimePicker} 
              />
              <DateTimePickerModal
                isVisible={isTimePickerVisible}
                mode="time"
                onConfirm={handleTimeConfirm}
                onCancel={hideTimePicker}
              />
              <Text style={styles.errorMessagePicker}>{horaConsultaError}</Text> 
          </View>         
          <Text style={styles.textDataRegistrar}>
            Tipo de aviso:
          </Text>
            < Picker style={styles.pickerRegistrar}
                selectedValue = {diaSelecionado} 
                onValueChange = { ( itemValue)  => {
                  setDiaSelecionado (itemValue)
                  setDiaSelecionadoError(null)
                }} 
                >            
                  <Picker.Item label='' value=''/> 
                  <Picker.Item label='1 dia antes' value='1dia'/>
                  <Picker.Item label='2 dias antes' value='2dia'/> 
                  <Picker.Item label='7 dias antes' value='7dia'/>     
              </Picker> 
              <Text style={styles.errorMessageLast}>{diaSelecionadoError}</Text> 
        </View> 
    </View>     
  );
}