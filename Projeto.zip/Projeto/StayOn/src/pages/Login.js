import React, { useState } from 'react';
import { View, Image, TouchableOpacity, Text, TextInput, Keyboard, Pressable} from 'react-native';
import styles from '../style/MainStyle';
import usuarioService from '../services/UsuarioService';





export default function Login({navigation}) {

  //const usadas para criacao do Login
  const [email, setEmail] = useState(null);
  const [senha, setSenha] = useState(null);
  const [emailError, setEmailError] = useState(null);
  const [senhaError, setSenhaError] = useState(null);  

  //Funcoes para validar campos da tela Login
  const validar = () => {
    let error = false;
    setEmailError(null);
    setSenhaError(null);
    const re = /^(([^<>()[\]\.,;:\s@\"]+(\.[^<>()[\]\.,;:\s@\"]+)*)|(\".+\"))@(([^<>()[\]\.,;:\s@\"]+\.)+[^<>()[\]\.,;:\s@\"]{2,})$/i;
    if(!re.test(String(email).toLowerCase()) ||email == null){
      setEmailError('*Preencha seu e-mail corretamente');
      error = true;
    }if(senha == null){
      setSenhaError('*Preencha sua senha corretamente');
      error = true;
    }
    return !error;
   };

  const entrar = ()=> {
    if(validar()){

      let data = {
        email: email,
        senha: senha,
      }

      usuarioService.logar(data)
        .then((response) => {
          setLoading(false);
          const titulo = (response.data.status) ? 'Sucesso' : 'Erro';
          setTitulo(titulo);
          setMensagem(response.data.mensagem);          
          showDialog();     
        })
        .catch((error) => {
          setLoading(false);
          setTitulo('Erro');
          setMensagem('Houve um erro inesperado');
        })    
      navigation.reset({
        index: 0,
        routes: [{name: "Principal"}]
      })
    }    
  };


  //Funcao para ir ate Tela Cadastro
  const cadastrar = () => {    
    navigation.navigate("Cadastro");    
  }

  return (    
    <Pressable onPress={Keyboard.dismiss}  style={styles.container}>      
      <View style={styles.boxLogo}>
        <Image source={require('../img/logo.jpg')} style={styles.imagelogo}/> 
        <Text style={styles.textLogo}>Stay On</Text>
      </View>
      <View style={styles.boxContext}>        
        <TextInput
          style={styles.imputContext}
          placeholder = "E-mail"
          keyboardType='email-address'         
          onChangeText = {value => {           
            setEmail(value)
            setEmailError(null)
          }}         
        />
        <Text style={styles.errorMessage}>{emailError}</Text>     
        <TextInput 
          style={styles.imputContext} 
          placeholder = "Senha"       
          onChangeText = {value => {
            setSenha(value)
            setSenhaError(null)
          }}
          secureTextEntry= {true}
        /> 
        <Text style={styles.errorMessage}>{senhaError}</Text>        
        <TouchableOpacity 
          style={styles.buttonLogin}
          onPress={() => entrar()}        
        >
            <Text style={styles.textButtonLogin}>Login</Text>
        </TouchableOpacity>
        <TouchableOpacity 
          style={styles.buttonLogin}
          onPress={() => cadastrar()}
        >
            <Text style={styles.textButtonLogin}>Cadastre-se</Text>
        </TouchableOpacity>       
      </View>     
    </Pressable>    
  );
}


