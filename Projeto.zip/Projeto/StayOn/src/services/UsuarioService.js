import axios from "axios";


class UsuarioService{

    async cadastrar(data){
        return axios({
            url: "http://192.168.15.18:3000/usuario/cadastrar",
            method: "POST",
            timeout: 5000,
            data: data,
            headers: {
                Accept: 'application/json'
            }
        }).then((response) => {
            return Promise.resolve(response);
        }).catch ((error) => {
            return Promise.reject(error);
        })
    }

    async logar(data){
        return axios({
            url: Config.API_URL + "http://192.168.15.18:3000/usuario/login",
            method: "POST",
            timeout: 5000,
            data: data,
            headers: {
                Accept: 'application/json'
            }
        }).then((response) => {
            return Promise.resolve(response)
        }).catch((error) => {
            return Promise.reject(error)
        })
    }
}

const usuarioService = new UsuarioService();
export default usuarioService;