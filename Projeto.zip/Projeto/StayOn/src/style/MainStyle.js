import { StyleSheet} from 'react-native';



const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#FFFFFF',
        marginTop: -10,
    },

    boxLogo:{
        alignItems: `center`,
        justifyContent: `center`,
    },

    imageLogoTabela:{
        width: 100,
        height: 100,
        marginTop: 10,

    },

    imagelogo:{
        width: 200,
        height: 200,
        marginTop: 10,
    },

    textLogo:{
        fontSize: 40,
        fontWeight:`bold`,
        color: `#646464`,
        paddingBottom: 30,
        marginTop: -30,
    }, 

    textLogoLogaout:{
        fontSize: 40,
        fontWeight:`bold`,
        color: `#646464`,
        paddingBottom: 30,
        marginTop: 30,
        textAlign: `center`,
    },

    imagelogoCadastro:{
        width: 200,
        height: 200,
    },      

    boxContext:{
        width: `90%`,
        marginLeft: `5%`,
        backgroundColor: `#dcdcdc`,
        borderRadius: 20,
        padding: 10,
        paddingBottom: 30,  
    },    
    

    textContext: {
        color: `#646464`,
        fontSize: 20,
        padding: 5,      
    },    

    imputContext:{
        width: `96%`,
        height: 40,
        marginLeft: `2%`,
        paddingLeft: 20,
        fontSize: 20,
        backgroundColor: `#FFFFFF`,
        borderRadius: 50,        
    },

    buttonLogin:{
        height: 40,
        alignItems: `center`,
        justifyContent: `center`,
        backgroundColor: `#646464`,
        marginTop: 20,
        borderRadius: 50,       
    },

    textButtonLogin:{
        color: `#ffc640`,
        fontSize: 24,
    },

    buttonCadastro:{
        height: 40,
        alignItems: `center`,
        justifyContent: `center`,
        backgroundColor: `#646464`,
        borderRadius: 50,       
    },

    textButtonCadastro:{
        color: `#ffc640`,
        fontSize: 24,
    },

    buttonModal:{
        width: `90%`,
        height: 40,
        alignItems: `center`,
        justifyContent: `center`,
        backgroundColor: `#646464`,
        marginTop: -10,
        marginBottom: 20,
        borderRadius: 50,       
    },

    textButtonModal:{
        color: `#ffc640`,
        fontSize: 24,
    },

    card:{
        padding: 10, 
        margin: 10, 
        height: 120
    },

    textAlarme:{
        fontSize: 24,
        fontWeight: `bold`,
        paddingLeft: 10,
    },

    textAlarmeAtivoDesativo:{
        fontSize: 15,
        marginLeft: 190,
        marginTop: -25,
    },

    textAlarmeHora:{
        fontSize: 20,
        paddingTop: 5,
        paddingLeft: 10,
        paddingBottom: 10,
        color: `#646464`,
        fontWeight: `bold`,
    },

    buttonParar:{
        width: 100,
        height: 25,
        backgroundColor: `red`,
        merginTop: 5,
        marginLeft: 10,
        borderRadius:30,
    },

    textParar:{
        alignItems: `center`,
        color: `#FFFFFF`,
        fontSize: 20,
        fontWeight: `bold`,

    },

    buttonAtivar:{
        width: 100,
        height: 25,
        backgroundColor: `green`,
        marginLeft: 150,
        borderRadius:30,
        marginTop: -25,
    },

    buttonFechar:{
        width: 25,
        height: 25,
        backgroundColor: `#646464`,
        marginLeft: 300,
        marginTop: -25,
        borderRadius:30,
    },

    cardTabela:{
        width: `90%`,
        height: 70,
        padding: 10, 
        margin: `5%`, 
        
    },

    errorMessage:{
        fontSize: 14,
        color:`red`,
        fontWeight: `bold`,   
        paddingBottom: 15,     
        marginLeft: 10,
    },

    errorMessageLast:{
        fontSize: 14,
        color:`red`,
        fontWeight: `bold`,      
        marginLeft: 10,
    },

    errorMessagePicker:{
        fontSize: 14,
        color:`red`,
        fontWeight: `bold`,      
        marginLeft: 10,
        marginTop: 50,
    },

    containerGeral:{
        width: `90%`,
        height: 700,        
        marginTop: 10,             
    },
    
    containerRegistro:{
        width: `100%`,
        height: 105,
        marginTop: 10,
        borderRadius: 30,    
        borderWidth: 3,
        borderColor: "#646464",     
    },   

    buttonRegistrar:{
        width: `90%`,
        height: 40,
        alignItems: `center`,
        justifyContent: `center`,
        backgroundColor: `#646464`,
        marginTop: 30,
        marginBottom: 20,
        marginLeft: `5%`,
        borderRadius: 50,       
    },

    textButtonRegistrar:{
        color: `#ffc640`,
        fontSize: 24,
    },

    textRegistrar:{       
        marginBottom: 5,
        paddingLeft: 5,        
        fontSize: 22,
        color: `#646464`,
        fontWeight: `bold`,
    },

    textRegistrarAdaptado:{
        marginTop: -15,
        marginBottom: 5,
        paddingLeft: 5,        
        fontSize: 22,
        color: `#646464`,
        fontWeight: `bold`,

    },

    textDataRegistrar: {
        marginBottom: 5,
        marginTop: 0,
        paddingLeft: 5,        
        fontSize: 22,
        color: `#646464`,
        fontWeight: `bold`,
    },

    pickerRegistrar:{
        marginLeft: 5,      
        backgroundColor:`#FFFFFF`,
    },

    textImputData:{       
        textAlign: `center`,     
        width: 220,
        height: 50,
        marginLeft: 5,        
        fontSize: 22,
        color: `#646464`,
        fontWeight: `bold`,
        backgroundColor:`#FFFFFF`,
        paddingTop: 10,
    },  
    
    buttonRegistrarConsumo:{
        width: `80%`,
        height: 40,
        alignItems: `center`,
        justifyContent: `center`,
        backgroundColor: `#32a726`,
        marginLeft: `10%`,
        marginTop: 10,
        borderRadius: 50,       
    },   

    buttonVerTabela:{
        width: `80%`,
        height: 40,
        alignItems: `center`,
        justifyContent: `center`,
        backgroundColor: `#646464`,
        marginLeft: `10%`,
        marginTop: 10,
        borderRadius: 50,       
    },   

    textButtonLogoutSim:{
        width: `80%`,
        height: 40,
        alignItems: `center`,
        justifyContent: `center`,
        backgroundColor: `#32a726`,
        marginLeft: `10%`,
        marginTop: 100,
        borderRadius: 50,         
    },    

    textButtonLogout:{
        color: `#ffc640`,
        fontSize: 26,
        fontWeight: `bold`,
    },

    dialogTitulo:{
        textAlign: `center`,
        fontSize: 28,
        fontWeight: `bold`,
        color: `blue`,
    },
    dialogMesagem:{
        textAlign: `center`,
        fontSize: 17,
    },

    buttonMesagem:{
        fontSize: 22,
    },
    
  });


export default styles;