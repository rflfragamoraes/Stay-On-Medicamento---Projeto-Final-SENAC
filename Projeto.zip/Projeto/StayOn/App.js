import React from 'react';
import { View } from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createStackNavigator } from '@react-navigation/stack';
import styles from './src/style/MainStyle';
import Login from './src/pages/Login';
import Cadastro from './src/pages/Cadastro';
import Principal from './src/pages/Principal';
import CriarAlarme from './src/pages/CriarAlarme';
import CriarMedico from './src/pages/CriarMedico';
import Tabela from './src/pages/Tabela';



//headerLeft: null (opcao para tirar a seta de voltar)

const Stack = createStackNavigator();

function MyPages() {
  return (
    <NavigationContainer>
      <Stack.Navigator style={styles.container}>
        <Stack.Screen  name= "Login" component={Login} options={{ title: ""}}/>
        <Stack.Screen name= "Cadastro" component={Cadastro} options={{ title: ""}}/>
        <Stack.Screen name= "Principal" component={Principal} options={{ title: ""}}/>     
        <Stack.Screen name= "CriarAlarme" component={CriarAlarme} options={{ title: ""}}/>  
        <Stack.Screen name= "CriarMedico" component={CriarMedico} options={{ title: ""}}/> 
        <Stack.Screen name= "Tabela" component={Tabela} options={{ title: ""}}/>         
      </Stack.Navigator>
    </NavigationContainer>
  );
}

export default function App() {
  return (
    <View style={styles.container}>
      <MyPages/>      
    </View>
  );
}



